#include"QueueWithLinklist.h"
#include"StackWithLinklist.h"
int main()
{
	int var = 0;
	QueueWithLinklest<int>Queueobj;
	StackWithLinklist<int>stackobj;
	cout << "enter 1 for using stack\n";
	cout << "enter 2 for using queue\n";

	cin >> var;
	if (var==1)
	{
		int value, op1 = 0;
		while (op1!=10)
		{


			cout << "enter 1 for push function\n";
			cout << "enter 2 for pop function\n";
			cout << "enter 3 for peek function\n";
			cout << "enter 4 for display function\n";
			cout << "enter 5 for exit\n";
			cin >> op1;
			switch (op1)
			{
			case 1:
				cout << "enter value to push\n";
				cin >> value;
				stackobj.push(value);
				break;
			case 2:
				cout << "pop value = " << stackobj.pop()<<"\n";
				break;
			case 3:
				cout << "peek value = " << stackobj.peek()<<"\n";
				break;
			case 4:
				stackobj.display();
				break;
			case 5:
				if (true)
				{
					op1=10;
				}
				break;


			default:
				cout << "please enter correct value\n";
				break;
			}
		}
	}
	else if (var == 2)
	{
		int op2=0, value=0;
		while (op2 != 10)
		{

		cout << "enter 1 for enqueue function\n";
		cout << "enter 2 for dequeue function\n";
		cout << "enter 3 for getrear function\n";
		cout << "enter 4 for getfront function\n";
		cout << "enter 5 for display\n";
		cout << "enter 6 for exit\n";
		cin >> op2;
		

			switch (op2)
			{
			case 1:
				cout << "enter value to enqueue\n";
				cin >> value;
				Queueobj.enqueue(value);
				break;
			case 2:
				cout << "dequeue value = " << Queueobj.dequeue()<<"\n";
				break;
			case 3:
				cout << "getrear value = " << Queueobj.getrear()<<"\n";
				break;
			case 4:
				cout << "getFront value = " << Queueobj.getfront()<<"\n";
				break;
			case 5:
				Queueobj.display();
				break;
			case 6:
				if (true)
				{
					op2 = 10;
				}
				break;


			default:
				cout << "please enter correct value\n";
				break;
			}
		}
	}
}